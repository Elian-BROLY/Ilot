using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace NotchPixel.Widgets;

public partial class ShelfWidget : UserControl
{
    private Point _pressPosition;
    private ShelfItem? _pressedItem;

    public ShelfWidget()
    {
        InitializeComponent();
        ItemsList.ItemsSource = Items;
        Items.CollectionChanged += (_, _) =>
            EmptyHint.Visibility = Items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        IsVisibleChanged += (_, _) =>
        {
            if (IsVisible)
            {
                RemoveMissingFiles();
            }
        };
    }

    /// <summary>Levé à la fin d'un glisser sortant, quel qu'en soit le résultat.</summary>
    public event Action? DragOutCompleted;

    public ObservableCollection<ShelfItem> Items { get; } = [];

    public bool IsDraggingOut { get; private set; }

    public bool IsDropHighlighted
    {
        set => Root.BorderBrush = value ? (System.Windows.Media.Brush)FindResource("AccentBrush") : System.Windows.Media.Brushes.Transparent;
    }

    public void AddFiles(IEnumerable<string> paths)
    {
        foreach (var path in paths)
        {
            if (Items.All(item => !string.Equals(item.Path, path, StringComparison.OrdinalIgnoreCase)))
            {
                Items.Add(new ShelfItem(path));
            }
        }
    }

    private void RemoveMissingFiles()
    {
        foreach (var item in Items.Where(item => !item.Exists).ToList())
        {
            Items.Remove(item);
        }
    }

    private void Item_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _pressedItem = (ShelfItem)((FrameworkElement)sender).DataContext;
        _pressPosition = e.GetPosition(this);
        // Capture : un geste rapide peut sortir de la ligne avant le premier MouseMove.
        ((UIElement)sender).CaptureMouse();
        e.Handled = true; // Saisir un fichier ne doit pas verrouiller la capsule.
    }

    private void Item_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        _pressedItem = null;
        ((UIElement)sender).ReleaseMouseCapture();
    }

    private void Item_MouseMove(object sender, MouseEventArgs e)
    {
        if (_pressedItem is not { } item || e.LeftButton != MouseButtonState.Pressed)
        {
            _pressedItem = null;
            return;
        }

        var delta = e.GetPosition(this) - _pressPosition;
        if (Math.Abs(delta.X) < SystemParameters.MinimumHorizontalDragDistance
            && Math.Abs(delta.Y) < SystemParameters.MinimumVerticalDragDistance)
        {
            return;
        }

        _pressedItem = null;
        ((UIElement)sender).ReleaseMouseCapture();
        IsDraggingOut = true;
        var data = new DataObject(DataFormats.FileDrop, new[] { item.Path });
        DragDrop.DoDragDrop((DependencyObject)sender, data, DragDropEffects.Copy | DragDropEffects.Move | DragDropEffects.Link);
        IsDraggingOut = false;

        // Un déplacement vers l'Explorateur retire le fichier d'origine : la référence n'a plus lieu d'être.
        if (!item.Exists)
        {
            Items.Remove(item);
        }
        DragOutCompleted?.Invoke();
    }

    private void Remove_Click(object sender, RoutedEventArgs e) =>
        Items.Remove((ShelfItem)((FrameworkElement)sender).DataContext);
}
