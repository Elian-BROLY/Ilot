using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Windows.Media.Control;
using Windows.Storage.Streams;

namespace NotchPixel.Services;

/// <summary>Suit la session média courante du système via GSMTC. <see cref="Changed"/> est levé sur le thread UI.</summary>
internal sealed class MediaService
{
    private const int ThumbnailDecodeWidth = 144; // 72 DIP en 200 %

    private readonly Dispatcher _dispatcher;
    private GlobalSystemMediaTransportControlsSessionManager? _manager;
    private GlobalSystemMediaTransportControlsSession? _session;
    private int _refreshVersion;

    public MediaService(Dispatcher dispatcher) => _dispatcher = dispatcher;

    public event Action? Changed;

    public bool HasSession { get; private set; }
    public bool IsPlaying { get; private set; }
    public bool CanGoPrevious { get; private set; }
    public bool CanTogglePlayPause { get; private set; }
    public bool CanGoNext { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public string Artist { get; private set; } = string.Empty;
    public BitmapSource? Thumbnail { get; private set; }

    public async Task InitializeAsync()
    {
        try
        {
            _manager = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
        }
        catch (Exception)
        {
            return; // GSMTC indisponible : le widget reste sur son état vide.
        }
        _manager.CurrentSessionChanged += (_, _) => _dispatcher.InvokeAsync(AttachCurrentSession);
        AttachCurrentSession();
    }

    public Task PreviousAsync() => SendAsync(s => s.TrySkipPreviousAsync().AsTask());

    public Task TogglePlayPauseAsync() => SendAsync(s => s.TryTogglePlayPauseAsync().AsTask());

    public Task NextAsync() => SendAsync(s => s.TrySkipNextAsync().AsTask());

    private async Task SendAsync(Func<GlobalSystemMediaTransportControlsSession, Task<bool>> command)
    {
        if (_session is { } session)
        {
            try
            {
                await command(session);
            }
            catch (Exception)
            {
                // La session a pu disparaître entre le clic et l'envoi : CurrentSessionChanged mettra l'état à jour.
            }
        }
    }

    private void AttachCurrentSession()
    {
        if (_session is not null)
        {
            _session.MediaPropertiesChanged -= OnMediaPropertiesChanged;
            _session.PlaybackInfoChanged -= OnPlaybackInfoChanged;
        }

        _session = _manager?.GetCurrentSession();
        if (_session is not null)
        {
            _session.MediaPropertiesChanged += OnMediaPropertiesChanged;
            _session.PlaybackInfoChanged += OnPlaybackInfoChanged;
        }

        UpdatePlaybackInfo();
        _ = RefreshMediaPropertiesAsync();
    }

    private void OnMediaPropertiesChanged(GlobalSystemMediaTransportControlsSession sender, MediaPropertiesChangedEventArgs args) =>
        _dispatcher.InvokeAsync(() => _ = RefreshMediaPropertiesAsync());

    private void OnPlaybackInfoChanged(GlobalSystemMediaTransportControlsSession sender, PlaybackInfoChangedEventArgs args) =>
        _dispatcher.InvokeAsync(UpdatePlaybackInfo);

    private void UpdatePlaybackInfo()
    {
        HasSession = _session is not null;
        IsPlaying = false;
        CanGoPrevious = CanTogglePlayPause = CanGoNext = false;
        try
        {
            if (_session?.GetPlaybackInfo() is { } info)
            {
                IsPlaying = info.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;
                CanGoPrevious = info.Controls.IsPreviousEnabled;
                CanTogglePlayPause = info.Controls.IsPlayPauseToggleEnabled;
                CanGoNext = info.Controls.IsNextEnabled;
            }
        }
        catch (Exception)
        {
            // Session fermée pendant la lecture de son état.
        }
        Changed?.Invoke();
    }

    private async Task RefreshMediaPropertiesAsync()
    {
        var version = ++_refreshVersion;
        var title = string.Empty;
        var artist = string.Empty;
        BitmapSource? thumbnail = null;

        if (_session is { } session)
        {
            try
            {
                var properties = await session.TryGetMediaPropertiesAsync();
                title = properties.Title ?? string.Empty;
                artist = properties.Artist ?? string.Empty;
                if (properties.Thumbnail is { } reference)
                {
                    thumbnail = await Task.Run(() => DecodeThumbnailAsync(reference));
                }
            }
            catch (Exception)
            {
                // Certaines applications ferment la session pendant la requête : on garde l'état vide.
            }
        }

        if (version != _refreshVersion)
        {
            return; // Une requête plus récente a démarré entre-temps.
        }
        Title = title;
        Artist = artist;
        Thumbnail = thumbnail;
        Changed?.Invoke();
    }

    private static async Task<BitmapSource?> DecodeThumbnailAsync(IRandomAccessStreamReference reference)
    {
        using var winrtStream = await reference.OpenReadAsync();
        using var source = winrtStream.AsStreamForRead();
        using var buffer = new MemoryStream();
        await source.CopyToAsync(buffer);
        buffer.Position = 0;

        var image = new BitmapImage();
        image.BeginInit();
        image.CacheOption = BitmapCacheOption.OnLoad;
        image.DecodePixelWidth = ThumbnailDecodeWidth;
        image.StreamSource = buffer;
        image.EndInit();
        image.Freeze();
        return image;
    }
}
