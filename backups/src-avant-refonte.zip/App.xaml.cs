using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using NotchPixel.Services;

namespace NotchPixel;

public partial class App : Application
{
    private Mutex? _singleInstance;
    private TrayIcon? _tray;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _singleInstance = new Mutex(initiallyOwned: true, @"Local\NotchPixel.SingleInstance", out var isFirstInstance);
        if (!isFirstInstance)
        {
            Shutdown();
            return;
        }

        // Une fenêtre aussi petite n'a pas besoin du GPU, et éviter Direct3D économise beaucoup de mémoire.
        RenderOptions.ProcessRenderMode = RenderMode.SoftwareOnly;

        _tray = new TrayIcon(Shutdown);
        new MainWindow().Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _tray?.Dispose();
        _singleInstance?.Dispose();
        base.OnExit(e);
    }
}
