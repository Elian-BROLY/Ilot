using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NotchPixel.Services;

namespace NotchPixel.Widgets;

public partial class MediaWidget : UserControl
{
    private readonly Brush _emptyArtwork;

    public MediaWidget()
    {
        InitializeComponent();
        _emptyArtwork = Artwork.Background;
        Service = new MediaService(Dispatcher);
        Service.Changed += Render;
        Render();
        _ = Service.InitializeAsync();
    }

    internal MediaService Service { get; }

    private void Render()
    {
        var hasTrack = Service.HasSession && Service.Title.Length > 0;
        TitleText.Text = hasTrack ? Service.Title : "Aucune lecture en cours";
        ArtistText.Text = hasTrack ? Service.Artist : string.Empty;

        PreviousButton.IsEnabled = Service.CanGoPrevious;
        PlayPauseButton.IsEnabled = Service.CanTogglePlayPause;
        NextButton.IsEnabled = Service.CanGoNext;
        PlayPauseButton.Content = Service.IsPlaying ? "" : "";

        if (Service.Thumbnail is { } thumbnail)
        {
            var brush = new ImageBrush(thumbnail) { Stretch = Stretch.UniformToFill };
            brush.Freeze();
            Artwork.Background = brush;
            ArtworkPlaceholder.Visibility = Visibility.Collapsed;
        }
        else
        {
            Artwork.Background = _emptyArtwork;
            ArtworkPlaceholder.Visibility = Visibility.Visible;
        }
    }

    private void Previous_Click(object sender, RoutedEventArgs e) => _ = Service.PreviousAsync();

    private void PlayPause_Click(object sender, RoutedEventArgs e) => _ = Service.TogglePlayPauseAsync();

    private void Next_Click(object sender, RoutedEventArgs e) => _ = Service.NextAsync();
}
