using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using NotchPixel.Controls;
using NotchPixel.Interop;

namespace NotchPixel;

public partial class MainWindow : Window
{
    private const double CompactWidth = 180;
    private const double CompactHeight = 32;
    private const double CompactRadius = 16;
    private const double ExpandedWidth = 420;
    private const double ExpandedHeight = 160;
    private const double ExpandedHeightWithAirPods = 208;
    private const double ExpandedRadius = 24;
    private const double BannerWidth = 320;
    private const double BannerHeight = 60;
    private const double BannerRadius = 30;

    private static readonly Color CompactFill = Color.FromRgb(0x0D, 0x0D, 0x0D);
    private static readonly Color ExpandedFill = Color.FromArgb(0xEB, 0x16, 0x16, 0x1A);
    private static readonly Thickness CompactBorder = new(0);
    private static readonly Thickness ExpandedBorder = new(1);
    private static readonly Brush ExpandedBorderBrush = CreateFrozenBrush(Color.FromArgb(0x24, 0xFF, 0xFF, 0xFF));

    private static readonly DependencyProperty CapsuleRadiusProperty = DependencyProperty.Register(
        nameof(CapsuleRadius), typeof(double), typeof(MainWindow),
        new PropertyMetadata(CompactRadius, (d, e) =>
            ((MainWindow)d).Capsule.CornerRadius = new CornerRadius(Math.Max(0, (double)e.NewValue))));

    private readonly DispatcherTimer _clockTimer = new(DispatcherPriority.Background);
    private readonly DispatcherTimer _expandTimer = new() { Interval = TimeSpan.FromMilliseconds(100) };
    private readonly DispatcherTimer _collapseTimer = new() { Interval = TimeSpan.FromMilliseconds(300) };
    private readonly DispatcherTimer _trimTimer = new() { Interval = TimeSpan.FromSeconds(5) };
    private readonly DispatcherTimer _bannerTimer = new() { Interval = TimeSpan.FromSeconds(3.5) };
    private IntPtr _hwnd;
    private bool _isExpanded;
    private bool _isBannerVisible;
    private bool _isPinned;
    private bool _pressStartedOnCapsule;

    public MainWindow()
    {
        InitializeComponent();
        _clockTimer.Tick += (_, _) => UpdateClock();
        _expandTimer.Tick += (_, _) =>
        {
            _expandTimer.Stop();
            Expand();
        };
        _collapseTimer.Tick += (_, _) => TryCollapse();
        _trimTimer.Tick += (_, _) =>
        {
            _trimTimer.Stop();
            // Au repos, rend au système les pages qui n'ont servi qu'au démarrage ou à l'animation.
            if (!_isExpanded)
            {
                NativeMethods.SetProcessWorkingSetSize(NativeMethods.GetCurrentProcess(), -1, -1);
            }
        };
        _trimTimer.Start();
        _bannerTimer.Tick += (_, _) =>
        {
            _bannerTimer.Stop();
            if (_isBannerVisible)
            {
                Collapse();
            }
        };
        AirPodsPanel.AvailabilityChanged += UpdateAirPodsLayout;
        AirPodsPanel.ConnectionChanged += OnAirPodsConnectionChanged;
        AirPodsPanel.BatteryChanged += () => BannerRings.Update(AirPodsPanel.Battery);
        _ = AirPodsPanel.InitializeAsync();
        MediaPanel.Service.Changed += UpdateCompactIndicators;
        ShelfPanel.Items.CollectionChanged += (_, _) => UpdateCompactIndicators();
        ShelfPanel.DragOutCompleted += _collapseTimer.Start;
        UpdateClock();
    }

    private double CurrentExpandedHeight => AirPodsPanel.IsAvailable ? ExpandedHeightWithAirPods : ExpandedHeight;

    private void UpdateAirPodsLayout()
    {
        AirPodsPanel.Visibility = AirPodsPanel.IsAvailable ? Visibility.Visible : Visibility.Collapsed;
        ExpandedPanel.Height = CurrentExpandedHeight;
        if (_isExpanded)
        {
            Animate(Capsule, HeightProperty, CurrentExpandedHeight, TimeSpan.FromMilliseconds(260), new CubicEase { EasingMode = EasingMode.EaseInOut });
        }
        UpdateCompactIndicators();
    }

    private void OnAirPodsConnectionChanged(bool isConnected)
    {
        UpdateCompactIndicators();
        // Panneau ouvert : la ligne AirPods affiche déjà le changement.
        if (!_isExpanded)
        {
            ShowBanner(isConnected);
        }
    }

    private void ShowBanner(bool isConnected)
    {
        BannerNameText.Text = AirPodsPanel.DeviceName;
        BannerStatusText.Text = isConnected ? "Connectés" : "Déconnectés";
        BannerRings.Update(isConnected ? AirPodsPanel.Battery : null);
        BannerRings.Visibility = isConnected ? Visibility.Visible : Visibility.Collapsed;
        AirPodsPanel.IsBannerWatching = isConnected;

        _trimTimer.Stop();
        _bannerTimer.Stop();
        _bannerTimer.Start();
        if (_isBannerVisible)
        {
            return;
        }
        _isBannerVisible = true;

        BannerPanel.Visibility = Visibility.Visible;
        var duration = TimeSpan.FromMilliseconds(380);
        var spring = new SpringEase();
        Animate(Capsule, WidthProperty, BannerWidth, duration, spring);
        Animate(Capsule, HeightProperty, BannerHeight, duration, spring);
        Animate(this, CapsuleRadiusProperty, BannerRadius, duration, null);
        Animate(CompactContent, OpacityProperty, 0, TimeSpan.FromMilliseconds(90), null);
        Animate(BannerPanel, OpacityProperty, 1, TimeSpan.FromMilliseconds(220), null, TimeSpan.FromMilliseconds(90));
    }

    private void HideBannerContent()
    {
        _isBannerVisible = false;
        _bannerTimer.Stop();
        AirPodsPanel.IsBannerWatching = false;
        Animate(BannerPanel, OpacityProperty, 0, TimeSpan.FromMilliseconds(100), null);
    }

    private void UpdateCompactIndicators()
    {
        AirPodsIndicator.Visibility = AirPodsPanel.IsConnected ? Visibility.Visible : Visibility.Collapsed;
        PlayingIndicator.Visibility = MediaPanel.Service.IsPlaying ? Visibility.Visible : Visibility.Collapsed;
        ShelfIndicator.Visibility = ShelfPanel.Items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        ShelfCountText.Text = ShelfPanel.Items.Count.ToString(CultureInfo.InvariantCulture);
    }

    private bool CanAcceptDrop(DragEventArgs e) =>
        !ShelfPanel.IsDraggingOut && e.Data.GetDataPresent(DataFormats.FileDrop);

    private void Capsule_DragEnter(object sender, DragEventArgs e)
    {
        Capsule_DragOver(sender, e);
        if (e.Effects != DragDropEffects.None)
        {
            _expandTimer.Stop();
            _collapseTimer.Stop();
            ShelfPanel.IsDropHighlighted = true;
            Expand();
        }
    }

    private void Capsule_DragOver(object sender, DragEventArgs e)
    {
        e.Effects = CanAcceptDrop(e) ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    private void Capsule_DragLeave(object sender, DragEventArgs e)
    {
        // Aussi levé en passant d'un enfant à l'autre : TryCollapse vérifie la position réelle du curseur.
        if (!IsCursorOverCapsule())
        {
            ShelfPanel.IsDropHighlighted = false;
        }
        if (_isExpanded && !_isPinned)
        {
            _collapseTimer.Start();
        }
    }

    private void Capsule_Drop(object sender, DragEventArgs e)
    {
        ShelfPanel.IsDropHighlighted = false;
        var isAccepted = CanAcceptDrop(e) && e.Data.GetData(DataFormats.FileDrop) is string[];
        if (isAccepted)
        {
            ShelfPanel.AddFiles((string[])e.Data.GetData(DataFormats.FileDrop));
        }
        // Sans valeur explicite, WPF renvoie tous les effets permis : la source pourrait conclure à un
        // déplacement et supprimer son fichier, alors que le panier ne garde qu'une référence.
        e.Effects = isAccepted ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;

        // WPF ne suit pas le survol pendant un glisser : MouseLeave peut ne jamais arriver après le dépôt.
        _collapseTimer.Start();
    }

    private double CapsuleRadius
    {
        get => (double)GetValue(CapsuleRadiusProperty);
        set => SetValue(CapsuleRadiusProperty, value);
    }

    private static Brush CreateFrozenBrush(Color color)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }

    private void Capsule_MouseEnter(object sender, MouseEventArgs e)
    {
        _collapseTimer.Stop();
        if (!_isExpanded)
        {
            _expandTimer.Start();
        }
    }

    private void Capsule_MouseLeave(object sender, MouseEventArgs e)
    {
        _expandTimer.Stop();
        _pressStartedOnCapsule = false;
        if (_isExpanded && !_isPinned)
        {
            _collapseTimer.Start();
        }
    }

    private void Capsule_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) => _pressStartedOnCapsule = true;

    private void Capsule_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (!_pressStartedOnCapsule)
        {
            return;
        }
        _pressStartedOnCapsule = false;

        _isPinned = !_isPinned;
        PinGlyph.Text = _isPinned ? "" : "";
        PinGlyph.Foreground = _isPinned ? Brushes.White : (Brush)FindResource("TextSecondaryBrush");
        if (_isPinned)
        {
            _expandTimer.Stop();
            _collapseTimer.Stop();
            Expand();
        }
    }

    private void TryCollapse()
    {
        _collapseTimer.Stop();
        if (_isPinned || !_isExpanded)
        {
            return;
        }
        // Filet de sécurité : ignore un MouseLeave parasite si le curseur est encore sur la capsule.
        if (IsCursorOverCapsule() || Mouse.Captured is not null || ShelfPanel.IsDraggingOut)
        {
            _collapseTimer.Start();
            return;
        }
        Collapse();
    }

    private bool IsCursorOverCapsule()
    {
        NativeMethods.GetCursorPos(out var cursor);
        var topLeft = Capsule.PointToScreen(default);
        var bottomRight = Capsule.PointToScreen(new Point(Capsule.ActualWidth, Capsule.ActualHeight));
        return cursor.X >= topLeft.X && cursor.X < bottomRight.X && cursor.Y >= topLeft.Y && cursor.Y < bottomRight.Y;
    }

    private void Expand()
    {
        if (_isExpanded)
        {
            return;
        }
        _isExpanded = true;
        _trimTimer.Stop();
        if (_isBannerVisible)
        {
            HideBannerContent();
        }

        ExpandedPanel.Visibility = Visibility.Visible;
        CapsuleShadow.Visibility = Visibility.Visible;
        Capsule.BorderBrush = ExpandedBorderBrush;
        Capsule.BorderThickness = ExpandedBorder;

        var duration = TimeSpan.FromMilliseconds(380);
        var spring = new SpringEase();
        Animate(Capsule, WidthProperty, ExpandedWidth, duration, spring);
        Animate(Capsule, HeightProperty, CurrentExpandedHeight, duration, spring);
        Animate(this, CapsuleRadiusProperty, ExpandedRadius, duration, null);
        CapsuleFill.BeginAnimation(SolidColorBrush.ColorProperty, new ColorAnimation(ExpandedFill, TimeSpan.FromMilliseconds(200)));
        Animate(CompactContent, OpacityProperty, 0, TimeSpan.FromMilliseconds(90), null);
        Animate(ExpandedPanel, OpacityProperty, 1, TimeSpan.FromMilliseconds(220), null, TimeSpan.FromMilliseconds(90));
        Animate(CapsuleShadow, OpacityProperty, 1, TimeSpan.FromMilliseconds(220), null);
    }

    private void Collapse()
    {
        _isExpanded = false;
        if (_isBannerVisible)
        {
            HideBannerContent();
        }

        var duration = TimeSpan.FromMilliseconds(260);
        var ease = new CubicEase { EasingMode = EasingMode.EaseInOut };
        var sizeAnimation = new DoubleAnimation(CompactHeight, duration) { EasingFunction = ease };
        sizeAnimation.Completed += (_, _) =>
        {
            // Une réouverture ou une bannière a pu survenir pendant l'animation.
            if (!_isExpanded && !_isBannerVisible)
            {
                BannerPanel.Visibility = Visibility.Collapsed;
                ExpandedPanel.Visibility = Visibility.Collapsed;
                CapsuleShadow.Visibility = Visibility.Hidden;
                Capsule.BorderThickness = CompactBorder;
                _trimTimer.Start();
            }
        };
        Capsule.BeginAnimation(HeightProperty, sizeAnimation);
        Animate(Capsule, WidthProperty, CompactWidth, duration, ease);
        Animate(this, CapsuleRadiusProperty, CompactRadius, duration, null);
        CapsuleFill.BeginAnimation(SolidColorBrush.ColorProperty, new ColorAnimation(CompactFill, duration));
        Animate(ExpandedPanel, OpacityProperty, 0, TimeSpan.FromMilliseconds(100), null);
        Animate(CompactContent, OpacityProperty, 1, TimeSpan.FromMilliseconds(160), null, TimeSpan.FromMilliseconds(100));
        Animate(CapsuleShadow, OpacityProperty, 0, duration, null);
    }

    private static void Animate(IAnimatable target, DependencyProperty property, double to, TimeSpan duration,
        IEasingFunction? ease, TimeSpan delay = default)
    {
        target.BeginAnimation(property, new DoubleAnimation(to, duration) { EasingFunction = ease, BeginTime = delay });
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _hwnd = new WindowInteropHelper(this).Handle;

        // Pas de vol de focus au clic, et invisible dans Alt+Tab.
        var style = NativeMethods.GetWindowLongPtr(_hwnd, NativeMethods.GWL_EXSTYLE).ToInt64();
        style |= NativeMethods.WS_EX_NOACTIVATE | NativeMethods.WS_EX_TOOLWINDOW;
        NativeMethods.SetWindowLongPtr(_hwnd, NativeMethods.GWL_EXSTYLE, new IntPtr(style));

        HwndSource.FromHwnd(_hwnd)!.AddHook(WndProc);
        PositionOnPrimaryScreen();
    }

    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg is NativeMethods.WM_DISPLAYCHANGE or NativeMethods.WM_DPICHANGED)
        {
            // Différé : WPF applique d'abord sa propre mise à l'échelle.
            Dispatcher.BeginInvoke(PositionOnPrimaryScreen, DispatcherPriority.Loaded);
        }
        return IntPtr.Zero;
    }

    /// <summary>Centre la fenêtre en haut de l'écran principal, en pixels physiques (High-DPI).</summary>
    private void PositionOnPrimaryScreen()
    {
        var monitor = NativeMethods.MonitorFromPoint(default, NativeMethods.MONITOR_DEFAULTTOPRIMARY);
        var info = new NativeMethods.MONITORINFO { cbSize = System.Runtime.InteropServices.Marshal.SizeOf<NativeMethods.MONITORINFO>() };
        if (!NativeMethods.GetMonitorInfo(monitor, ref info))
        {
            return;
        }
        NativeMethods.GetDpiForMonitor(monitor, NativeMethods.MDT_EFFECTIVE_DPI, out var dpi, out _);

        var width = (int)Math.Round(Width * dpi / 96.0);
        var height = (int)Math.Round(Height * dpi / 96.0);
        var left = info.rcMonitor.Left + (info.rcMonitor.Right - info.rcMonitor.Left - width) / 2;

        NativeMethods.SetWindowPos(_hwnd, NativeMethods.HWND_TOPMOST, left, info.rcMonitor.Top, width, height,
            NativeMethods.SWP_NOACTIVATE);
    }

    private void UpdateClock()
    {
        var now = DateTime.Now;
        ClockText.Text = now.ToString("HH:mm", CultureInfo.InvariantCulture);
        ExpandedClockText.Text = ClockText.Text;

        // Un seul réveil par minute, calé sur le changement de minute.
        _clockTimer.Interval = TimeSpan.FromSeconds(60 - now.Second) - TimeSpan.FromMilliseconds(now.Millisecond);
        _clockTimer.Start();
    }
}
