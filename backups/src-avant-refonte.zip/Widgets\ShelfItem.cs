using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using NotchPixel.Interop;

namespace NotchPixel.Widgets;

/// <summary>Référence vers un fichier déposé : le fichier lui-même reste à son emplacement d'origine.</summary>
public sealed class ShelfItem
{
    public ShelfItem(string path)
    {
        Path = path;
        var name = System.IO.Path.GetFileName(path.TrimEnd(System.IO.Path.DirectorySeparatorChar));
        Name = name.Length > 0 ? name : path; // Racine de lecteur : pas de nom de fichier.
        Icon = LoadIcon(path);
    }

    public string Path { get; }
    public string Name { get; }
    public ImageSource? Icon { get; }

    public bool Exists => File.Exists(Path) || Directory.Exists(Path);

    private static ImageSource? LoadIcon(string path)
    {
        var info = new NativeMethods.SHFILEINFO();
        var result = NativeMethods.SHGetFileInfo(path, 0, ref info, (uint)Marshal.SizeOf<NativeMethods.SHFILEINFO>(),
            NativeMethods.SHGFI_ICON | NativeMethods.SHGFI_LARGEICON);
        if (result == IntPtr.Zero || info.hIcon == IntPtr.Zero)
        {
            return null;
        }

        try
        {
            var icon = Imaging.CreateBitmapSourceFromHIcon(info.hIcon, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            icon.Freeze();
            return icon;
        }
        finally
        {
            NativeMethods.DestroyIcon(info.hIcon);
        }
    }
}
